

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="card" id="customerList">

                <div class="card-header border-bottom-dashed">

                    <div class="row g-4 align-items-center">
                        <div class="col-sm">
                            <div>
                                <h5 class="card-title mb-0">Country List</h5>
                            </div>
                        </div>
                        
                    </div>
                </div>


                <div class="card-body border-bottom-dashed border-bottom">
                    
                        <div class="row g-3">
                            <div class="col-xl-6">
                                <div class="search-box">
                                    <input type="text" class="form-control search"
                                        placeholder="Search for customer, email, phone, status or something...">
                                    <i class="ri-search-line search-icon"></i>
                                </div>
                            </div>
                            <div class="col-xl-6">
                                <a  class="btn btn-dange" href="<?php echo e(route('admin.qualification.create')); ?>"> Add </a>
                            </div>

                            <!--end col-->
                            
                        </div>

                            <!--end col-->
                            

                        <!--end row-->
                    
                </div>

                <div class="card-body">
                    <div>
                        <div class="table-responsive table-card mb-1">
                            <table class="table align-middle" id="customerTable">
                                <thead class="table-light text-muted">
                                    <tr>
                                        <th scope="col" style="width: 50px;">
                                            S.N
                                        </th>

                                        <th class="sort" data-sort="customer_name">name</th>
                                        <th class="sort" data-sort="created_at">created at</th>
                                        <th class="sort" data-sort="action">Action</th>
                                    </tr>
                                </thead>
                                <tbody class="list form-check-all">
                                    <?php $__currentLoopData = $qualifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th scope="row">
                                            <?php echo e(++$key); ?>

                                        </th>
                                        
                                        <td class="customer_name"><?php echo e($item->name); ?></td>
                                        <td class="date"><?php echo e($item->created_at); ?></td>
                                        <td class="status"><span
                                                class="badge badge-soft-success text-uppercase">Active</span>
                                        </td>
                                        <td>
                                            <ul class="list-inline hstack gap-2 mb-0">
                                                <li class="list-inline-item edit" data-bs-toggle="tooltip"
                                                    data-bs-trigger="hover" data-bs-placement="top" title="Edit">
                                                    <a href="<?php echo e(route('admin.qualification.edit',$item->id)); ?>" 
                                                        class="text-primary d-inline-block edit-item-btn">
                                                        <i class="ri-pencil-fill fs-16"></i>
                                                    </a>
                                                </li>
                                                <li class="list-inline-item delete_item" model="Qualification" item_id="<?php echo e($item->id); ?>" data-bs-toggle="tooltip"
                                                    
                                                    title="Remove">
                                                    

                                                        
                                                            <i class="ri-delete-bin-5-fill fs-16 text-danger d-inline-block remove-item-btn"></i>
                                                        
                                                    

                                                </li>
                                            </ul>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            
                        </div>
                        <div class="d-flex justify-content-end ">
                        <div class="pagination-wrap hstack gap-2">
                            <a class="page-item pagination-prev disabled" href="#">
                                Previous
                            </a>
                            <ul class="pagination listjs-pagination mb-0"></ul>
                            <a class="page-item pagination-next" href="#">
                                Next
                            </a>
                        </div>
                    </div>
                    </div>
                    
                </div>
            </div>

        </div>
        <!--end col-->
    </div>

    <!--end row-->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/seojotco/public_html/metronomy/resources/views/admin/qualification/index.blade.php ENDPATH**/ ?>