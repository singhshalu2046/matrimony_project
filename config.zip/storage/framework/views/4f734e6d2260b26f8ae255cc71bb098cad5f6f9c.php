<?php echo $__env->yieldContent('css'); ?>
<!-- Layout config Js -->
<script src="<?php echo e(URL::asset('admin/assets/js/layout.js')); ?>"></script>
<!-- Bootstrap Css -->
<link href="<?php echo e(URL::asset('admin/assets/css/bootstrap.min.css')); ?>"  rel="stylesheet" type="text/css" />
<!-- Icons Css -->
<link href="<?php echo e(URL::asset('admin/assets/css/icons.min.css')); ?>" rel="stylesheet" type="text/css" />
<!-- App Css-->
<link href="<?php echo e(URL::asset('admin/assets/css/app.min.css')); ?>"  rel="stylesheet" type="text/css" />
<!-- custom Css-->
<link href="<?php echo e(URL::asset('admin/assets/css/custom.min.css')); ?>"  rel="stylesheet" type="text/css" />

<?php /**PATH /home/seojotco/public_html/metronomy/resources/views/admin/layouts/head-css.blade.php ENDPATH**/ ?>