

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-lg-12">
        <div class="card" id="customerList">
            <div class="card-header border-bottom-dashed">

                <div class="row g-4 align-items-center">
                    <div class="col-sm">
                        <div>
                            <h5 class="card-title mb-0">User List</h5>
                        </div>
                    </div>
                    
                </div>
            </div>
            <div class="card-body">

            
                <form method="POST" action="<?php echo e(route("admin.customer.update", [$user->id])); ?>" enctype="multipart/form-data">
                    <?php echo method_field('PUT'); ?>
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="id" value="<?php echo e($user->id); ?>">
                    <div class="form-group">
                        <label class="required" for="user_name"><?php echo e(trans('cruds.user.fields.user_name')); ?></label>
                        <input class="form-control <?php echo e($errors->has('user_name') ? 'is-invalid' : ''); ?>" type="text" name="user_name" id="user_name" value="<?php echo e(old('user_name', $user->user_name)); ?>" step="1" required>
                        <?php if($errors->has('user_name')): ?>
                            <span class="text-danger"><?php echo e($errors->first('user_name')); ?></span>
                        <?php endif; ?>
                        <span class="help-block"><?php echo e(trans('cruds.user.fields.user_name_helper')); ?></span>
                    </div>


                    <div class="form-group">
                    <label class="required" for="email"><?php echo e(trans('cruds.user.fields.email')); ?></label>
                    <input class="form-control <?php echo e($errors->has('email') ? 'is-invalid' : ''); ?>" type="email" name="email" id="email" value="<?php echo e(old('email', $user->email)); ?>" step="1" required>
                    <?php if($errors->has('email')): ?>
                        <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                    <?php endif; ?>
                    <span class="help-block"><?php echo e(trans('cruds.user.fields.email_helper')); ?></span>
                </div>


                <div class="form-group">
                    <label class="required" for="contact_number"><?php echo e(trans('cruds.user.fields.contact_number')); ?></label>
                    <input class="form-control <?php echo e($errors->has('contact_number') ? 'is-invalid' : ''); ?>" type="number" name="contact_number" id="contact_number" value="<?php echo e(old('contact_number', $user->contact_number)); ?>" step="1" required>
                    <?php if($errors->has('contact_number')): ?>
                        <span class="text-danger"><?php echo e($errors->first('contact_number')); ?></span>
                    <?php endif; ?>
                    <span class="help-block"><?php echo e(trans('cruds.user.fields.contact_number_helper')); ?></span>
                </div>
                    <div class="form-group">
                        <button class="btn btn-danger" type="submit">
                        Save
                        </button>
                    </div>
                </form>
                
            </div>
        </div>
    </div>
    <!--end col-->
</div>
    <!--end row-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/seojotco/public_html/metronomy/resources/views/admin/customerEdit.blade.php ENDPATH**/ ?>