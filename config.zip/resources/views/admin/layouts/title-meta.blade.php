<meta charset="utf-8" />
<title>@yield('title') | Velzon - Admin & Dashboard Template</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta content="" name="description" />
<meta content="" name="author" />
<!-- App favicon -->
<link rel="shortcut icon" href="{{ URL::asset('admin/assets/images/favicon.ico') }}">
